<?php
// search.php

require_once 'api.php';
require_once 'nlp.php';

if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['q'])) {
    $query = trim($_GET['q']);
    if (!empty($query)) {
        // Fetch results from APIs
        $duckduckgoResults = fetchFromDuckDuckGo($query);
        $newsResults = fetchFromNewsAPI($query);
        $wikiResults = fetchFromWikipedia($query);

        // Combine results
        $allResults = [];
        if (isset($duckduckgoResults['RelatedTopics'])) {
            foreach ($duckduckgoResults['RelatedTopics'] as $result) {
                $allResults[] = [
                    'title' => $result['Text'],
                    'link' => $result['FirstURL'] ?? '#',
                    'snippet' => $result['Text'],
                ];
            }
        }
        if (isset($newsResults['articles'])) {
            foreach ($newsResults['articles'] as $article) {
                $allResults[] = [
                    'title' => $article['title'],
                    'link' => $article['url'],
                    'snippet' => $article['description'],
                ];
            }
        }
        if (isset($wikiResults['query']['search'])) {
            foreach ($wikiResults['query']['search'] as $result) {
                $allResults[] = [
                    'title' => $result['title'],
                    'link' => "https://en.wikipedia.org/wiki/" . urlencode($result['title']),
                    'snippet' => $result['snippet'],
                ];
            }
        }

        // Rank results using NLP
        $rankedResults = rankResults($allResults, $query);
    }
}
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>نتایج جستجو - tarnamagard.ir</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.rtl.min.css" rel="stylesheet">
    <!-- Custom CSS -->
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
    <div class="container mt-5">
        <h1>نتایج جستجو برای "<strong><?= htmlspecialchars($query ?? '') ?></strong>"</h1>

        <?php if (isset($rankedResults)): ?>
            <?php if (count($rankedResults) > 0): ?>
                <div class="row">
                    <?php foreach ($rankedResults as $result): ?>
                        <div class="col-md-12 mb-4">
                            <div class="card">
                                <div class="card-body">
                                    <h5 class="card-title">
                                        <a href="<?= htmlspecialchars($result['link']) ?>" target="_blank" class="text-decoration-none">
                                            <?= htmlspecialchars($result['title'] ?? 'بدون عنوان') ?>
                                        </a>
                                    </h5>
                                    <p class="card-text"><?= htmlspecialchars($result['snippet'] ?? '') ?></p>
                                    <a href="<?= htmlspecialchars($result['link']) ?>" target="_blank" class="btn btn-primary btn-sm">مشاهده</a>
                                </div>
                            </div>
                        </div>
                    <?php endforeach; ?>
                </div>
            <?php else: ?>
                <div class="alert alert-warning" role="alert">
                    نتیجه‌ای یافت نشد. لطفاً عبارت جستجو را تغییر دهید.
                </div>
            <?php endif; ?>
        <?php endif; ?>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>