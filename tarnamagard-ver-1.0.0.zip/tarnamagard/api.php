<?php
// api.php

require_once 'db.php';

function fetchFromDuckDuckGo($query) {
    $url = "https://api.duckduckgo.com/?q=" . urlencode($query) . "&format=json&pretty=1";

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    $response = curl_exec($ch);
    curl_close($ch);

    return json_decode($response, true);
}

function fetchFromNewsAPI($query) {
    $apiKey = 'YOUR_NEWS_API_KEY'; // جایگزین کنید با کلید API خود
    $url = "https://newsapi.org/v2/everything?q=" . urlencode($query) . "&apiKey=$apiKey";

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    $response = curl_exec($ch);
    curl_close($ch);

    return json_decode($response, true);
}

function fetchFromWikipedia($query) {
    $url = "https://en.wikipedia.org/w/api.php?action=query&list=search&srsearch=" . urlencode($query) . "&format=json";

    $ch = curl_init();
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
    $response = curl_exec($ch);
    curl_close($ch);

    return json_decode($response, true);
}
?>