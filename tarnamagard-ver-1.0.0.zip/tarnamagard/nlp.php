<?php
// nlp.php

require_once 'vendor/autoload.php'; // برای استفاده از PHP-ML

use Phpml\FeatureExtraction\TokenCountVectorizer;
use Phpml\Tokenization\WordTokenizer;

/**
 * تبدیل متن به بردارهای عددی برای پردازش.
 */
function analyzeText($text) {
    $tokenizer = new WordTokenizer();
    $vectorizer = new TokenCountVectorizer($tokenizer);

    // تبدیل متن به بردارهای عددی
    $samples = [$text];
    $vectorizer->fit($samples);
    $vectorizer->transform($samples);

    return $samples[0];
}

/**
 * محاسبه شباهت بین دو بردار با استفاده از Cosine Similarity.
 */
function cosineSimilarity($vec1, $vec2) {
    $dotProduct = 0;
    $magnitude1 = 0;
    $magnitude2 = 0;

    foreach ($vec1 as $key => $value) {
        $dotProduct += ($value * ($vec2[$key] ?? 0));
        $magnitude1 += pow($value, 2);
    }

    foreach ($vec2 as $value) {
        $magnitude2 += pow($value, 2);
    }

    if ($magnitude1 == 0 || $magnitude2 == 0) {
        return 0;
    }

    return $dotProduct / (sqrt($magnitude1) * sqrt($magnitude2));
}

/**
 * استخراج کلمات کلیدی از متن.
 */
function extractKeywords($content) {
    // حذف کلمات کوتاه، اعداد و کاراکترهای غیرضروری
    $words = preg_split('/\s+/', $content);
    $keywords = array_filter($words, function ($word) {
        return strlen($word) > 3 && !is_numeric($word);
    });

    // حذف تکرارها
    return array_unique($keywords);
}

/**
 * رتبه‌بندی نتایج بر اساس شباهت به عبارت جستجو.
 */
function rankResults($results, $query) {
    $queryVector = analyzeText($query);
    $rankedResults = [];

    foreach ($results as $result) {
        $content = $result['snippet'] ?? '';
        $contentVector = analyzeText($content);

        // محاسبه شباهت با استفاده از Cosine Similarity
        $similarity = cosineSimilarity($queryVector, $contentVector);
        $rankedResults[] = ['result' => $result, 'score' => $similarity];
    }

    // مرتب‌سازی بر اساس امتیاز
    usort($rankedResults, function ($a, $b) {
        return $b['score'] <=> $a['score'];
    });

    return array_column($rankedResults, 'result');
}
?>