<?php
// crawler.php

require_once 'db.php';

use GuzzleHttp\Client;
use Symfony\Component\DomCrawler\Crawler as DomCrawler;

function crawlPage($url) {
    global $pdo;

    // Check if URL already exists in the database
    $stmt = $pdo->prepare("SELECT id FROM pages WHERE url = :url");
    $stmt->execute(['url' => $url]);
    if ($stmt->fetch()) {
        echo "URL already crawled: $url\n";
        return;
    }

    // Fetch page content
    $client = new Client();
    try {
        $response = $client->get($url, ['timeout' => 10]);
        $html = $response->getBody()->getContents();
    } catch (\Exception $e) {
        echo "Failed to fetch URL: $url\n";
        return;
    }

    // Parse HTML
    $domCrawler = new DomCrawler($html);
    $title = $domCrawler->filter('title')->text() ?? '';
    $description = $domCrawler->filter('meta[name="description"]')->attr('content') ?? '';
    $content = $domCrawler->filter('body')->text();

    // Insert into database
    $stmt = $pdo->prepare("INSERT INTO pages (url, title, description, content) VALUES (:url, :title, :description, :content)");
    $stmt->execute([
        'url' => $url,
        'title' => $title,
        'description' => $description,
        'content' => $content,
    ]);

    $pageId = $pdo->lastInsertId();

    // Extract keywords and links
    $keywords = extractKeywords($content);
    foreach ($keywords as $keyword) {
        $stmt = $pdo->prepare("INSERT INTO keywords (page_id, keyword) VALUES (:page_id, :keyword)");
        $stmt->execute(['page_id' => $pageId, 'keyword' => $keyword]);
    }

    $links = extractLinks($domCrawler);
    foreach ($links as $link) {
        queueForCrawling($link);
    }

    echo "Crawled URL: $url\n";
}

function extractKeywords($content) {
    $words = preg_split('/\s+/', $content);
    $keywords = array_filter($words, function ($word) {
        return strlen($word) > 3 && !is_numeric($word);
    });
    return array_unique($keywords);
}

function extractLinks(DomCrawler $domCrawler) {
    $links = [];
    $domCrawler->filter('a')->each(function (DomCrawler $node) use (&$links) {
        $href = $node->attr('href');
        if (filter_var($href, FILTER_VALIDATE_URL)) {
            $links[] = $href;
        }
    });
    return array_unique($links);
}

function queueForCrawling($url) {
    global $pdo;
    $stmt = $pdo->prepare("INSERT IGNORE INTO crawl_queue (url) VALUES (:url)");
    $stmt->execute(['url' => $url]);
}
?>