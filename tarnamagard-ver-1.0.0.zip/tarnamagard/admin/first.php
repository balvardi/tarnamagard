<?php
require_once '../db.php';

// Add initial admin user
$username = 'admin';
$password = 'password123'; // Change this to a strong password
$password_hash = password_hash($password, PASSWORD_BCRYPT);

$stmt = $pdo->prepare("INSERT INTO admins (username, password_hash) VALUES (:username, :password_hash)");
$stmt->execute(['username' => $username, 'password_hash' => $password_hash]);

echo "Admin user added successfully.";
?>