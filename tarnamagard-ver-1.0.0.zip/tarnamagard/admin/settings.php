<?php
// admin/settings.php

session_start();

if (!isset($_SESSION['admin_logged_in'])) {
    header('Location: login.php');
    exit;
}

require_once '../db.php';

// Save settings if form is submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $crawler_limit = (int)($_POST['crawler_limit'] ?? 0);
    $api_status = (int)($_POST['api_status'] ?? 0);

    // Update settings in database
    $stmt = $pdo->prepare("INSERT INTO settings (key_name, value) VALUES (:key, :value) ON DUPLICATE KEY UPDATE value = :value");
    $stmt->execute(['key' => 'crawler_limit', 'value' => $crawler_limit]);
    $stmt->execute(['key' => 'api_status', 'value' => $api_status]);

    echo '<div class="alert alert-success">تنظیمات با موفقیت ذخیره شد.</div>';
}

// Fetch current settings
$stmt = $pdo->query("SELECT * FROM settings");
$settings = [];
foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) as $row) {
    $settings[$row['key_name']] = $row['value'];
}
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>تنظیمات - tarnamagard.ir</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.rtl.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5">
        <h1>تنظیمات</h1>
        <form method="POST" action="">
            <div class="mb-3">
                <label for="crawler_limit" class="form-label">حداکثر تعداد صفحات برای Crawler</label>
                <input type="number" name="crawler_limit" id="crawler_limit" class="form-control" value="<?= htmlspecialchars($settings['crawler_limit'] ?? 100) ?>" required>
            </div>
            <div class="mb-3">
                <label for="api_status" class="form-label">وضعیت API‌ها</label>
                <select name="api_status" id="api_status" class="form-select">
                    <option value="1" <?= ($settings['api_status'] ?? 1) == 1 ? 'selected' : '' ?>>فعال</option>
                    <option value="0" <?= ($settings['api_status'] ?? 1) == 0 ? 'selected' : '' ?>>غیرفعال</option>
                </select>
            </div>
            <button type="submit" class="btn btn-primary">ذخیره تنظیمات</button>
        </form>
    </div>
</body>
</html>