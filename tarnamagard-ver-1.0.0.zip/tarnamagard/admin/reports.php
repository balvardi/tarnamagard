<?php
// admin/reports.php

session_start();

if (!isset($_SESSION['admin_logged_in'])) {
    header('Location: login.php');
    exit;
}

require_once '../db.php';

// Fetch top search queries
$stmt = $pdo->query("SELECT query, COUNT(*) AS count FROM searches GROUP BY query ORDER BY count DESC LIMIT 10");
$topQueries = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>گزارش‌ها - tarnamagard.ir</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.rtl.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5">
        <h1>گزارش‌ها</h1>
        <table class="table table-striped">
            <thead>
                <tr>
                    <th>عبارت جستجو</th>
                    <th>تعداد</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($topQueries as $query): ?>
                    <tr>
                        <td><?= htmlspecialchars($query['query']) ?></td>
                        <td><?= $query['count'] ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</body>
</html>