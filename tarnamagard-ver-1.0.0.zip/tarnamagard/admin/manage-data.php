<?php
// admin/manage-data.php

session_start();

if (!isset($_SESSION['admin_logged_in'])) {
    header('Location: login.php');
    exit;
}

require_once '../db.php';

// Delete page if requested
if (isset($_GET['delete']) && is_numeric($_GET['delete'])) {
    $pageId = (int)$_GET['delete'];
    $stmt = $pdo->prepare("DELETE FROM pages WHERE id = :id");
    $stmt->execute(['id' => $pageId]);
    echo '<div class="alert alert-success">صفحه با موفقیت حذف شد.</div>';
}

// Fetch all pages
$stmt = $pdo->query("SELECT * FROM pages ORDER BY created_at DESC");
$pages = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>مدیریت داده‌ها - tarnamagard.ir</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.rtl.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5">
        <h1>مدیریت داده‌ها</h1>
        <table class="table table-striped">
            <thead>
                <tr>
                    <th>#</th>
                    <th>عنوان</th>
                    <th>URL</th>
                    <th>تاریخ ایجاد</th>
                    <th>عملیات</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($pages as $page): ?>
                    <tr>
                        <td><?= htmlspecialchars($page['id']) ?></td>
                        <td><?= htmlspecialchars($page['title']) ?></td>
                        <td><a href="<?= htmlspecialchars($page['url']) ?>" target="_blank"><?= htmlspecialchars($page['url']) ?></a></td>
                        <td><?= htmlspecialchars($page['created_at']) ?></td>
                        <td>
                            <a href="?delete=<?= $page['id'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('آیا مطمئنید؟')">حذف</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</body>
</html>