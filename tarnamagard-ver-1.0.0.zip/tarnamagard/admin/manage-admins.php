<?php
// admin/manage-admins.php

session_start();

if (!isset($_SESSION['admin_logged_in'])) {
    header('Location: login.php');
    exit;
}

require_once '../db.php';

// Add new admin if form is submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['new_username']) && isset($_POST['new_password'])) {
    $username = $_POST['new_username'];
    $password = $_POST['new_password'];
    $password_hash = password_hash($password, PASSWORD_BCRYPT);

    $stmt = $pdo->prepare("INSERT INTO admins (username, password_hash) VALUES (:username, :password_hash)");
    $stmt->execute(['username' => $username, 'password_hash' => $password_hash]);

    echo '<div class="alert alert-success">ادمین جدید با موفقیت اضافه شد.</div>';
}

// Fetch all admins
$stmt = $pdo->query("SELECT * FROM admins ORDER BY created_at DESC");
$admins = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>مدیریت ادمین‌ها - tarnamagard.ir</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.rtl.min.css" rel="stylesheet">
</head>
<body>
    <div class="container mt-5">
        <h1>مدیریت ادمین‌ها</h1>

        <!-- Add new admin form -->
        <h3>افزودن ادمین جدید</h3>
        <form method="POST" action="">
            <div class="mb-3">
                <label for="new_username" class="form-label">نام کاربری</label>
                <input type="text" name="new_username" id="new_username" class="form-control" required>
            </div>
            <div class="mb-3">
                <label for="new_password" class="form-label">رمز عبور</label>
                <input type="password" name="new_password" id="new_password" class="form-control" required>
            </div>
            <button type="submit" class="btn btn-primary">افزودن ادمین</button>
        </form>

        <!-- List of admins -->
        <h3 class="mt-5">لیست ادمین‌ها</h3>
        <table class="table table-striped">
            <thead>
                <tr>
                    <th>#</th>
                    <th>نام کاربری</th>
                    <th>تاریخ ایجاد</th>
                    <th>عملیات</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($admins as $admin): ?>
                    <tr>
                        <td><?= htmlspecialchars($admin['id']) ?></td>
                        <td><?= htmlspecialchars($admin['username']) ?></td>
                        <td><?= htmlspecialchars($admin['created_at']) ?></td>
                        <td>
                            <?php if ($admin['username'] !== 'admin'): ?>
                                <a href="?delete=<?= $admin['id'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('آیا مطمئنید؟')">حذف</a>
                            <?php endif; ?>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</body>
</html>