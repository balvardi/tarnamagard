<?php
// index.php
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ترنم آگرد - tarnamagard.ir</title>
    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.rtl.min.css" rel="stylesheet">
    <!-- Custom CSS -->
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
    <div class="container text-center mt-5">
        <h1 class="display-4">ترنم آگرد</h1>
        <p class="lead">موتور جستجوی محلی برای ایرانیان</p>
        <form method="GET" action="search.php" class="mt-4">
            <div class="input-group mb-3">
                <input type="text" name="q" class="form-control form-control-lg" placeholder="عبارت مورد نظر را جستجو کنید..." aria-label="جستجو" required>
                <button class="btn btn-primary btn-lg" type="submit">جستجو</button>
            </div>
        </form>
        <p class="text-muted">با استفاده از ترنم آگرد، به راحتی می‌توانید اطلاعات مورد نظر خود را پیدا کنید.</p>
    </div>

    <!-- Bootstrap JS -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>